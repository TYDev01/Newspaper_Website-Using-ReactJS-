<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->integer('role_id')->default(2);
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('pwd')->nullable();
            $table->string('pin')->nullable();
            $table->string('ssn')->nullable();
            $table->string('phone')->nullable();
            $table->string('country')->nullable();
            $table->string('city')->nullable();
            $table->string('address')->nullable();
            $table->string('zip_code')->nullable();
            $table->timestamp('phone_verified_at')->nullable();
            $table->double('balance')->nullable();
            $table->double('amount')->nullable();
            $table->string('account_number')->unique()->nullable();
            $table->integer('status')->default(1);
            $table->integer('two_step_auth')->default(0);
            $table->boolean('is_admin_created')->default(false);
            $table->boolean('can_credit')->default(true);
            $table->boolean('can_debit')->default(true);
            $table->string('image')->default('images/avatar.png');
            $table->rememberToken();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
