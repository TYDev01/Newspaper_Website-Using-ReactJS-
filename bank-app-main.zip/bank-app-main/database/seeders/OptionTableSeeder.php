<?php

namespace Database\Seeders;

use App\Models\Option;
use Illuminate\Database\Seeder;
use App\Models\Term;
use App\Models\Termmeta;
use App\Models\Menu;
use App\Models\Language;
use App\Models\Withdrawmethod;
use App\Models\Termwithdraw;
use Illuminate\Support\Str;

class OptionTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Option::create([
            'key'=>'seo',
            'value'=>'{"title":"Home","description":null,"canonical":null,"tags":null,"twitterTitle":null}',
        ]);
        $data = [
            'min_amount'     => '100',
            'max_amount'     => '2000',
            'fixed_charge'   => '30',
            'percent_charge' => '10',
            'charge_type'    => 'both',
        ];

        $option        = new Option();
        $option->key   = 'ownbank_charge';
        $option->value = json_encode($data);
        $option->save();


        $data = [
            'sender_charge' => '2',
            'receiver_charge' => '2',
            'charge_type' => 'percentage',
        ];

        $option = new Option();
        $option->key = 'bill_charge';
        $option->value = json_encode($data);
        $option->save();

        $data = [
            'phone_verification' => '',
            'email_verification' => 'on',
        ];


        $option = new Option();
        $option->key = 'verification_settings';
        $option->value = json_encode($data);
        $option->save();

        $data = [
            'twilio_sid' => '',
            'twilio_auth_token' => '',
            'twilio_number' => '',
            'message' => '',
        ];
        
        $option = new Option();
        $option->key = 'twilio_info';
        $option->value = json_encode($data);
        $option->save();


        // hero section

        $value = [
            'title'             => 'The Simple, Easiest way to grow and save your money.',
            'short_description' => 'Join over 9 million people who get the real exchange rate with '.env('APP_NAME').'. We’re on average 8x cheaper than leading banks worldwide.',
            'button_text'       => 'See How We Loan Money',
            'button_url'        => 'https://www.youtube.com/watch?v=y-AmnasDev0',
            'status'            => '1',
        ];

        $hero_section        = new Option();
        $hero_section->key   = 'hero_section';
        $hero_section->value = json_encode($value);
        $hero_section->save();

        // Counter Section
        $counter_data = [
            'happy_customers_no'      => '356,321',
            'happy_customers_title'   => 'Happy Customers',
            'year_banking_no'         => '3',
            'year_banking_title'      => 'Years in banking',
            'our_branches_no'         => '345',
            'our_branches_title'      => 'Our branches',
            'successfully_work_no'    => '5,285',
            'successfully_work_title' => 'Successfully works',
        ];

        $counter_data_in        = new Option();
        $counter_data_in->key   = 'counter';
        $counter_data_in->value = json_encode($counter_data);
        $counter_data_in->save();

        // how it work title
        
        $how_it_work        = new Option();
        $how_it_work->key   = 'titles';
        $how_it_work->value = '{"client_title":"Clients Feedback","client_description":"Hear what our clients have to say.","hwt_title":"How It Works","hwt_description":"Get started to conducting safe and low charge financial transactions via the Internet.","tit_title":"Top Investors","tit_description":"Meet our top investors.","lnt_title":"Latest News","lnt_description":"Follow up on the latest banking trends on our blog.","bst_title":"Banking Services","bst_description":"What we offer.","hero_title":"The Simple, Easiest way to grow and save your money.","hero_description":"Join over 9 million people who get the real exchange rate with '.env('APP_NAME').'. We\u2019re on average 8x cheaper than leading banks worldwide.","hero_btn_title":"See How We Loan Money","hero_button_url":"https://www.youtube.com/watch?v=y-AmnasDev"}';
        $how_it_work->save();

      

        $theme        = new Option();
        $theme->key   = 'theme_settings';
        $theme->value = '{"footer_description":"'.env('APP_NAME').' is the leading name in internet banking trusted by numerous clients worldwide.","newsletter_address":"'.env('ADDRESS').'<br>'.env('MAIL_USERNAME').'","social":[{"icon":"ri:facebook-fill","link":"#"},{"icon":"ri:twitter-fill","link":"#"},{"icon":"ri:google-fill","link":"#"},{"icon":"ri:instagram-fill","link":"#"},{"icon":"ri:pinterest-fill","link":"#"}]}';
        $theme->save();

        
        $terms = array(
            array('id' => '1','title' => '1. Register for free','slug' => '1-register-for-free','type' => 'howitworks','status' => '1','featured' => '1','created_at' => '2021-02-07 08:15:38','updated_at' => '2021-02-07 08:15:38'),
            array('id' => '2','title' => '2. Choose an amount','slug' => '2-choose-an-amount','type' => 'howitworks','status' => '1','featured' => '1','created_at' => '2021-02-07 08:17:06','updated_at' => '2021-02-07 08:17:06'),
            array('id' => '3','title' => '3. Add recipient’s bank','slug' => '3-add-recipients-bank','type' => 'howitworks','status' => '1','featured' => '1','created_at' => '2021-02-07 08:17:26','updated_at' => '2021-02-07 08:17:26'),
            array('id' => '4','title' => '4. Authorize transaction','slug' => '4-verify-your-identity','type' => 'howitworks','status' => '1','featured' => '1','created_at' => '2021-02-07 08:17:44','updated_at' => '2021-02-07 08:17:44'),
            array('id' => '5','title' => '5. Pay for your transfer','slug' => '5-pay-for-your-transfer','type' => 'howitworks','status' => '1','featured' => '1','created_at' => '2021-02-07 08:18:07','updated_at' => '2021-02-07 08:18:07'),
            array('id' => '6','title' => '6. That’s it','slug' => '6-thats-it','type' => 'howitworks','status' => '1','featured' => '1','created_at' => '2021-02-07 08:18:48','updated_at' => '2021-02-07 08:18:48'),
            array('id' => '7','title' => 'Credit Card','slug' => 'credit-card','type' => 'services','status' => '1','featured' => '1','created_at' => '2021-02-07 08:27:35','updated_at' => '2021-02-07 08:27:35'),
            array('id' => '8','title' => 'Personal Loans','slug' => 'personal-loans','type' => 'services','status' => '1','featured' => '1','created_at' => '2021-02-07 08:28:18','updated_at' => '2021-02-07 08:28:18'),
            array('id' => '9','title' => 'Saving Account','slug' => 'saving-account','type' => 'services','status' => '1','featured' => '1','created_at' => '2021-02-07 08:29:01','updated_at' => '2021-02-07 08:29:01'),
            array('id' => '10','title' => 'Bussiness Banking','slug' => 'bussiness-banking','type' => 'services','status' => '1','featured' => '1','created_at' => '2021-02-07 08:30:19','updated_at' => '2021-02-07 08:30:19'),
            array('id' => '11','title' => 'Md. Json Deo','slug' => 'md-json-deo','type' => 'investor','status' => '1','featured' => '1','created_at' => '2021-02-07 08:31:18','updated_at' => '2021-02-07 08:31:18'),
            array('id' => '12','title' => 'Catherine White','slug' => 'md-json-deo','type' => 'investor','status' => '1','featured' => '1','created_at' => '2021-02-07 08:31:39','updated_at' => '2021-02-07 08:31:39'),
            array('id' => '13','title' => 'Maxim Micel','slug' => 'md-json-deo','type' => 'investor','status' => '1','featured' => '1','created_at' => '2021-02-07 08:31:50','updated_at' => '2021-02-07 08:31:50'),
            array('id' => '14','title' => 'Damian L. James','slug' => 'md-json-deo','type' => 'investor','status' => '1','featured' => '1','created_at' => '2021-02-07 08:32:01','updated_at' => '2021-02-07 08:32:01'),
            array('id' => '15','title' => 'Lucas R. Hernandez','slug' => 'md-jhon-deo','type' => 'feedback','status' => '1','featured' => '1','created_at' => '2021-02-07 08:32:51','updated_at' => '2021-02-07 08:32:51'),
            array('id' => '16','title' => 'Macon Vinson','slug' => 'macon-vinson','type' => 'feedback','status' => '1','featured' => '1','created_at' => '2021-02-07 08:33:09','updated_at' => '2021-02-07 08:33:09'),
            array('id' => '17','title' => 'Capturing opportunities in the race for renewable energy in MENA','slug' => Str::slug('Capturing opportunities in the race for renewable energy in MENA', '-'),'type' => 'news','status' => '1','featured' => '1','created_at' => '2021-02-07 08:34:11','updated_at' => '2021-02-07 08:34:11'),
            array('id' => '18','title' => 'How growth and innovation in credit insurance can unlock latent capital','slug' => Str::slug('How growth and innovation in credit insurance can unlock latent capital', '-'),'type' => 'news','status' => '1','featured' => '1','created_at' => '2021-02-07 08:34:38','updated_at' => '2021-02-07 08:34:38'),
            array('id' => '19','title' => 'Accelerating the path to net zero – the crucial role of finance and investment','slug' => Str::slug('Accelerating the path to net zero – the crucial role of finance and investment'),'type' => 'news','status' => '1','featured' => '1','created_at' => '2021-02-07 08:35:13','updated_at' => '2021-02-07 08:35:13'),
            array('id' => '20','title' => 'About','slug' => 'about','type' => 'page','status' => '1','featured' => '1','created_at' => '2021-02-10 09:11:09','updated_at' => '2021-02-10 09:11:09'),
            array('id' => '21','title' => 'Faq','slug' => 'faq','type' => 'page','status' => '1','featured' => '1','created_at' => '2021-02-10 09:33:12','updated_at' => '2021-02-10 09:33:12'),
            array('id' => '22','title' => 'INR','slug' => '72.86','type' => 'currency','status' => '1','featured' => '1','created_at' => '2021-02-10 10:19:02','updated_at' => '2021-02-10 10:19:02'),
            array('id' => '23','title' => 'CAD','slug' => '1.27','type' => 'currency','status' => '1','featured' => '1','created_at' => '2021-02-10 10:19:22','updated_at' => '2021-02-10 10:19:22'),
            array('id' => '24','title' => 'BTC','slug' => '0.000021','type' => 'currency','status' => '1','featured' => '1','created_at' => '2021-02-10 10:19:45','updated_at' => '2021-02-10 10:19:45')
        );

        Term::insert($terms);

        $termmetas = array(
            array('id' => '1','term_id' => '1','key' => 'howitworks','value' => '{"description":"Registration is completely free. Sign up now and get your bank account number instantly and start transacting.","image":"uploads\\/21\\/02\\/1691023560954847.png"}'),
            array('id' => '2','term_id' => '2','key' => 'howitworks','value' => '{"description":"Enter desired amount in available currencies. Do not worry about the rates as we offer the lowest possible rates..","image":"uploads\\/21\\/02\\/1691023653462586.png"}'),
            array('id' => '3','term_id' => '3','key' => 'howitworks','value' => '{"description":"Enter the beneficiary bank\'s name.","image":"uploads\\/21\\/02\\/1691023674505921.png"}'),
            array('id' => '4','term_id' => '4','key' => 'howitworks','value' => '{"description":"You will need your four(4) digit transaction pin to authorize transactions. Create one or update from your account settings tab after signup.","image":"uploads\\/21\\/02\\/1691023692819314.png"}'),
            array('id' => '5','term_id' => '5','key' => 'howitworks','value' => '{"description":"We offer the lowest possible fees on transaction.","image":"uploads\\/21\\/02\\/1691023717524345.png"}'),
            array('id' => '6','term_id' => '6','key' => 'howitworks','value' => '{"description":"... and that\'s it. Join us and start saving.","image":"uploads\\/21\\/02\\/1691023759965205.png"}'),
            array('id' => '7','term_id' => '7','key' => 'services','value' => '{"description":"lol Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","short_description":"You shouldn’t have to pay to own a debit card. We’ll send a free one to your address at no cost and never charge you a card maintenance fee.","image":"uploads\\/21\\/02\\/1691024312116945.png"}'),
            array('id' => '8','term_id' => '8','key' => 'services','value' => '{"description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","short_description":"We understand that our clients might get into financial needs sometimes so we designed some nice loan packages.","image":"uploads\\/21\\/02\\/1691024357803023.png"}'),
            array('id' => '9','term_id' => '9','key' => 'services','value' => '{"description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","short_description":"Money saved today can save you tommorrow. Sign up and see how we help you save.","image":"uploads\\/21\\/02\\/1691024403235113.png"}'),
            array('id' => '10','term_id' => '10','key' => 'services','value' => '{"description":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","short_description":"Our services make banking easy and transparent whilst providing solutions that support your business growth.","image":"uploads\\/21\\/02\\/1691024484429138.png"}'),
            array('id' => '11','term_id' => '11','key' => 'investor','value' => '{"position":"Top Investor","facebook_link":"#","twitter_link":"#","linkedin_link":"#","image":"uploads\\/21\\/02\\/1691024546818640.png"}'),
            array('id' => '12','term_id' => '12','key' => 'investor','value' => '{"position":"Top Investor","facebook_link":"#","twitter_link":"#","linkedin_link":"#","image":"uploads\\/21\\/02\\/1691024568726071.png"}'),
            array('id' => '13','term_id' => '13','key' => 'investor','value' => '{"position":"Top Investor","facebook_link":"#","twitter_link":"#","linkedin_link":"#","image":"uploads\\/21\\/02\\/1691024580466670.png"}'),
            array('id' => '14','term_id' => '14','key' => 'investor','value' => '{"position":"Top Investor","facebook_link":"#","twitter_link":"#","linkedin_link":"#","image":"uploads\\/21\\/02\\/74ygeye8dh733838.jpeg"}'),
            array('id' => '15','term_id' => '15','key' => 'feedback','value' => '{"client_image":"uploads\\/21\\/02\\/200221181250.jpeg","client_review":"I’m very impressed with the assistance provided by customer service at'.env('APP_NAME').' Bank! I was looking to open a new account, but was hesitant to pull the trigger. I had many questions that the customer service representative was able to address & answer with ease & patience to ensure I understood completely in order to make the best decisions. '.env('APP_NAME').' Bank is simply the best!","client_position":"CEO, Merger ltd"}'),
            array('id' => '16','term_id' => '16','key' => 'feedback','value' => '{"client_image":"uploads\\/21\\/02\\/283245678.jpeg","client_review":"I recently opened an account with '.env('APP_NAME').' Bank and their representatives were extremely helpful in explaining how to use and make transactions through this site. I was very impressed with their customers service team and would recommend this bank for anybody who is looking for a company who has your back and best interest at heart. Thank you!","client_position":"Head Of Marketing, Pornce Insurance"}'),
            array('id' => '17','term_id' => '17','key' => 'excerpt','value' => 'Here’s how collaboration and innovative financing can supercharge MENA’s renewable energy ambitions.'),
            array('id' => '18','term_id' => '17','key' => 'thum_image','value' => 'uploads/21/02/1691024727674365.jpg'),
            array('id' => '19','term_id' => '17','key' => 'description','value' => 'Blessed with abundant renewable resources, the Middle East and North Africa is at the forefront of green energy development and has been moving away from hydrocarbon reliance for more than a decade.
            Now, as technology enables the capture of ever-greater quantities of energy from solar, wind and water systems, this region and its developers are offering increasingly compelling investment opportunities.
            More renewable projects are needed to meet the ambitious targets set by countries in the region, which amount to 80 GW of renewable capacity by 20301, according to the International Renewable Energy Agency, that’s up from around 28 GW now, and implies billions of dollars of investment over the coming years.
            The region is well positioned for success, benefitting from land availability, plentiful sunshine and high wind speeds in some geographies, low capital and labour costs and a good track record of delivering return on investment. Solar and wind projects are proliferating, offering investor potential, while new opportunities are emerging in green hydrogen and waste-to-energy projects.
            The region’s energy sector also remains attractive to foreign and local investors, because of a favourable global business environment and proactive sustainable and environment regulatory changes. However, financing these capital- intensive projects is still a challenge.'),
            array('id' => '20','term_id' => '18','key' => 'excerpt','value' => 'Credit insurance is rapidly growing. Effective collaboration between banks, insurers, and reinsurers is channelling capital to developing-market projects.'),
            array('id' => '21','term_id' => '18','key' => 'thum_image','value' => 'uploads/21/02/1691024756592492.jpg'),
            array('id' => '22','term_id' => '18','key' => 'description','value' => 'Credit insurance, which protects financial institutions, or sellers of goods and services, against bad debt and is therefore used as an important risk management tool, is in an exciting growth phase. As a result of innovation and effective collaboration between banks, insurers, and reinsurers, much latent capital has been unlocked, allowing a range of developing-market projects to take off which might have otherwise been deemed as ‘too risky’.
            So why is this tool not being used more broadly to channel funds to where they are most needed? The challenge lies in the market not being as well understood as it could be.
            The non-payment insurance market for single risks is worth an estimated €2.2bn pa in premiums and growing, and is used to facilitate an estimated €600bn of lending to the real economy, according to ITFA1. The World Trade Organization reports2 that 80% to 90% of world trade is in some way reliant on trade finance and that the private credit insurance market plays a significant role in this.
            “The market has really grown and become innovative over the past five years,” says Gary Lowe, Managing Director and Head, Global Credit Insurance Group at Standard Chartered. “There’s a real synergy between banks, clients, brokers, the insurers and reinsurers – it’s a fantastic piece of the credit market that could translate to channelling more capital to areas and projects that will benefit the most.”'),

            array('id' => '23','term_id' => '19','key' => 'excerpt','value' => 'As businesses and entire industries completely retool and refocus their priorities to achieve net zero targets, they must also look for ways to fund their transition.'),
            array('id' => '24','term_id' => '19','key' => 'thum_image','value' => 'uploads/21/02/1691024793346135.jpg'),
            array('id' => '25','term_id' => '19','key' => 'description','value' => 'Business and world leaders are aligned on the need to move to net zero, with thousands of large corporations setting ambitious goals to reduce emissions and bolster sustainability.
            And with wind, solar, electric vehicles and hydrogen being embraced on a grand scale, a renewable future seems well underway. Technology is already a critical enabler, helping to track and measure emissions as well as providing new ways to reduce them. Even so, more needs to be done and faster, with better collaboration and fast-tracking of financing opportunities to push businesses toward their targets. New initiatives like the Climate Impact X1, a global exchange for high-quality carbon credits can help make essential financial strides.
            “The transition to net zero requires vast amounts of capital, and the financial sector must play a leading role to make sure companies can transition, and those that are already transitioning have the support they need to flourish,” says Chris Leeds, Standard Chartered’s Executive Director, Head of Carbon Markets Development.'),
            array('id' => '26','term_id' => '20','key' => 'page','value' => '{"page_excerpt":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s.","page_content":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.","thum_image":"uploads\\/21\\/02\\/1691298844437341.jpg"}'),
            array('id' => '27','term_id' => '21','key' => 'page','value' => '{"page_excerpt":"Can I get information about my account by phone?<br>Is interest paid on my checking account?","page_content":"Yes! Account information is available with our Customer Service Representatives during business hours at any of our offices.<br><br>Yes! If you want a checking account that pays a market rate of interest, check out our Now, Super Now or Money Market Checking accounts.","thum_image":"uploads\\/21\\/02\\/1691300232318513.jpg"}'),
            array('id' => '28','term_id' => '22','key' => 'content','value' => '{"logo":"uploads\\/21\\/02\\/1691303115851719.png"}'),
            array('id' => '29','term_id' => '23','key' => 'content','value' => '{"logo":"uploads\\/21\\/02\\/1691303136495322.png"}'),
            array('id' => '30','term_id' => '24','key' => 'content','value' => '{"logo":"uploads\\/21\\/02\\/1691303160779365.png"}'),
            //  array('id' => '31','term_id' => '25','key' => 'page','value' => '{"page_excerpt":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,","page_content":"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."}')
        );       

        Termmeta::insert($termmetas);

        $menu = array(
          array('id' => '1','name' => 'Header','position' => 'header','data' => '[{"text":"Home","href":"/","icon":"empty","target":"_self","title":""},{"text":"Services","href":"/services","icon":"empty","target":"_self","title":""},{"text":"Latest News","href":"/news","icon":"empty","target":"_self","title":""},{"text":"Faq","href":"/page/faq","icon":"empty","target":"_self","title":""},{"text":"Contact","href":"/contact","icon":"empty","target":"_self","title":""}]','lang' => 'en','status' => '1','created_at' => '2021-02-08 04:20:13','updated_at' => '2021-02-10 09:36:41'),
          array('id' => '2','name' => 'Explore','position' => 'footer_left','data' => '[{"text":"Contact Us","icon":"empty","href":"/contact","target":"_self","title":""},{"text":"Faq","icon":"empty","href":"/page/faq","target":"_self","title":""},{"text":"Blog","icon":"empty","href":"/news","target":"_self","title":""}]','lang' => 'en','status' => '1','created_at' => '2021-02-15 14:09:46','updated_at' => '2021-02-15 14:16:03'),
          array('id' => '3','name' => 'Quick Links','position' => 'footer_right','data' => '[{"text":"My Account ","href":"/user/dashboard","icon":"","target":"_self","title":""},{"text":"Withdraw","icon":"","href":"/user/transfer/otherbank","target":"_self","title":""},{"text":"Support","href":"/user/support","icon":"empty","target":"_self","title":""},{"text":"Register","href":"/register","icon":"empty","target":"_self","title":""},{"text":"Login","href":"/user/login","icon":"empty","target":"_self","title":""}]','lang' => 'en','status' => '1','created_at' => '2021-02-15 14:10:14','updated_at' => '2021-02-15 14:30:08')
      );


        Menu::insert($menu);

        $languages = array(
            array('id' => '1','name' => 'en','position' => 'ltr','data' => 'English','status' => '1','created_at' => '2021-02-08 04:19:45','updated_at' => '2021-02-08 04:22:31')
        );

        Language::insert($languages);

        $withdrawmethods = array(
            array('id' => '1','title' => 'Low Cost Transfer','min_amount' => '50','max_amount' => '5000','charge_type' => 'fixed','fix_charge' => '2','percent_charge' => '0','status' => '1','created_at' => '2021-02-10 09:46:25','updated_at' => '2021-02-10 09:50:28'),
            array('id' => '2','title' => 'Fast & Easy Transfer','min_amount' => '50','max_amount' => '5000','charge_type' => 'both','fix_charge' => '2','percent_charge' => '2','status' => '1','created_at' => '2021-02-10 09:49:38','updated_at' => '2021-02-10 09:50:39')
        );
          
        Withdrawmethod::insert($withdrawmethods);

        $termwithdraws = array(
            array('term_id' => '23','withdrawmethod_id' => '1'),
            array('term_id' => '22','withdrawmethod_id' => '2'),
            array('term_id' => '23','withdrawmethod_id' => '2')
        );
        Termwithdraw::insert($termwithdraws);
          
    }
}
