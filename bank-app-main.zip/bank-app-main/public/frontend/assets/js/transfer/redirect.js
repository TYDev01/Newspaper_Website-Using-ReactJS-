"use strict";
function success(arg){
    var link = $('.redirectUrl').val();
    window.location.href = link;
}