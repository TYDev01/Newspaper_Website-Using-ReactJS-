@extends('layouts.backend.app')

@section('head')
@include('layouts.backend.partials.headersection',['title'=>'Transaction View'])
@endsection

@section('content')
<div class="row">
    <div class="col-8">
      <div class="card">
        <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th>{{ __('Title') }}</th>
                    <th>{{ __('Info') }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{{ __('User Name') }}</td>
                    <td>{{ $transaction->user->name }}</td>
                  </tr>
                  <tr>
                    <td>{{ __('Account Number') }}</td>
                    <td>{{ $transaction->user->account_number }}</td>
                  </tr>
                  @isset($transaction->user->amount)
                    <tr>
                      <td>{{ __('Amount') }}</td>
                      <td>{{ number_format($transaction->user->amount) }}</td>
                    </tr>
                  @endisset
                  <tr>
                    <td>{{ __('Balance') }}</td>
                    <td>{{ $transaction->user->balance }}</td>
                  </tr>
                  <tr>
                    <td>{{ __('Trx Id') }}</td>
                    <td>{{ $transaction->trxid }}</td>
                  </tr>
                  <tr>
                    <td>{{ __('Transaction Amount') }}</td>
                    <td>{{ number_format($transaction->amount) }}</td>
                  </tr>
                  <tr>
                    <td>{{ __('Fee') }}</td>
                    <td>{{ $transaction->fee }}</td>
                  </tr>
                  <tr>
                    <td>{{ __('Info') }}</td>
                    <td>{{ $transaction->info }}</td>
                  </tr>
                  <tr>
                    <td>{{ __('Type') }}</td>
                    <td>{{ ucwords(str_replace('otherbank', 'international', str_replace('ownbank', 'local', str_replace("_", " ", $transaction->type)))) }}</td>
                  </tr>

                  @isset($transaction->description)
                    <tr>
                      <td>{{ __('Description') }}</td>
                      <td>{{ $transaction->description }}</td>
                    </tr>
                  @endisset
                  <tr>
                    <td>{{ __('Status') }}</td>
                    <td>
                      <span class="badge badge-primary">{{ ($transaction->status == 1) ? 'success' : 'pending' }}</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
        </div>
      </div>
  </div>
</div>
@endsection