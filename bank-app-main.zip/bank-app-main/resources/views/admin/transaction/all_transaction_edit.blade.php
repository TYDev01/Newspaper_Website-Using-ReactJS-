@extends('layouts.backend.app')

@section('head')
@include('layouts.backend.partials.headersection',['title'=>"Edit Transaction: $transaction->trxid"])
@endsection

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <h4>{{ __('Edit Transaction') }}</h4>
            </div>
            @if ($errors->any())
              <div class="alert alert-danger">
                  <strong>{{ __('Whoops!') }}</strong> {{ __('There were some problems with your input.') }}<br><br>
                  <ul>
                      @foreach ($errors->all() as $error)
                          <li>{{ $error }}</li>
                      @endforeach
                  </ul>
              </div>
            @endif
            <form method="POST" action="{{ route('admin.all.transaction.update', $transaction->id) }}" class="basicform">
              @csrf
              @method('put')
              <div class="card-body">
                <div class="form-row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group">
                          <label>{{ __('Recipient Account Number') }}</label>
                          <input type="number" class="form-control" placeholder="Account Number" required name="account_no" value="{{ $transaction->account_no }}">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group">
                          <label>{{ __('Bank Name') }}</label>
                          <input type="text" class="form-control" placeholder="Bank Name" required name="bank_name" value="{{ $transaction->bank_name }}">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <div class="form-group">
                        <label>{{ __('Transaction Balance') }}</label>
                        <input type="number" class="form-control" placeholder="Balance" required name="balance" value="{{ $transaction->balance }}">
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <div class="form-group">
                        <label>{{ __('Amount') }}</label>
                        <input type="number" class="form-control" placeholder="Amount" required name="amount" value="{{ $transaction->amount }}">
                      </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <div class="form-group">
                          <label>{{ __('Transaction Fee') }}</label>
                          <input type="number" class="form-control" placeholder="Fee" required name="fee" value="{{ $transaction->fee }}">
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <div class="form-group">
                        <label>{{ __('Date') }}</label>
                        <input type="date" class="form-control" placeholder="Description" name="created_at" value="{{date('Y-m-d', strtotime($transaction->created_at))}}">
                      </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group">
                            <div class="custom-file mb-3">
                                <label>{{ __('Status') }}</label>
                                <select name="status" class="form-control">
                                <option>-- {{ __('Select Status') }} --</option>
                                <option value="1" {{ ($transaction->status == 1) ? 'selected' : '' }}>{{ __('Success') }}</option>
                                <option value="2" {{ ($transaction->status == 2) ? 'selected' : '' }}>{{ __('Pending') }}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group">
                            <div class="custom-file mb-3">
                            <label>{{ __('User') }}</label>
                            <select name="user_id" class="form-control">
                                <option>-- {{ __('Select User') }} --</option>
                                @foreach ($users as $user)
                                    <option value="{{$user->id}}" {{$user->id == $transaction->user_id ? 'selected' : ''}}>{{$user->name}}</option>
                                @endforeach
                            </select>
                            </div>
                        </div>
                    </div>
                </div>

                @if ($transaction->type == 'otherbank_transfer')
                    @php
                        $info = json_decode($transaction->otherbank->info)
                    @endphp
                    <div class="form-row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>{{ __('Recipient Name') }}</label>
                                <input type="text" class="form-control" placeholder="Recipient Name" required name="recipient_name" value="{{ $info->account_holder_name }}">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label>{{ __('Branch (Address)') }}</label>
                                <input type="text" class="form-control" placeholder="Branch" required name="branch" value="{{ $info->branch }}">
                            </div>
                        </div>
                    </div>
                @endif
                
                <div class="form-row">
                    <div class="col-12">
                        <div class="form-group">
                        <label>{{ __('Description (optional)') }}</label>
                        <textarea rows="2" class="form-control" placeholder="Description" name="description" minlength="5" maxlength="200">{{$transaction->description}}</textarea>
                        </div>
                    </div>
                </div>

                {{-- <div class="form-row">
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <div class="control-label">{{ __('Email verify status') }}</div>
                      <label class="custom-switch mt-2">
                        <input {{ ($user_edit->email_verified_at) ? 'checked' : '' }} type="checkbox" name="email_verified_at" class="custom-switch-input">
                        <span class="custom-switch-indicator"></span>
                        <span class="custom-switch-description">{{ __('verify') }}</span>
                      </label>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <div class="control-label">{{ __('Phone verify status') }}</div>
                      <label class="custom-switch mt-2">
                        <input {{ ($user_edit->phone_verified_at) ? 'checked' : '' }} type="checkbox" name="phone_verified_at" class="custom-switch-input">
                        <span class="custom-switch-indicator"></span>
                        <span class="custom-switch-description">{{ __('verify') }}</span>
                      </label>
                    </div>
                  </div>
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <div class="control-label two_step_auth">{{ __('2 Step Auth') }}</div>
                      <label class="custom-switch mt-2">
                        <input {{ ($user_edit->two_step_auth) ? 'checked' : '' }} type="checkbox" name="two_step_auth" class="custom-switch-input">
                        <span class="custom-switch-indicator"></span>
                        <span class="custom-switch-description">{{ __('Enable') }}</span>
                      </label>
                    </div>
                  </div>
              </div> --}}
              <div class="row">
                  <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-lg float-right w-100 basicbtn">{{ __('Update Transaction') }}</button>
                  </div>
                </div>
              </div>
            </form>
        </div>
    </div>
</div>
@endsection