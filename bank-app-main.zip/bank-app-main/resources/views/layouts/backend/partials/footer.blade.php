<footer class="main-footer">
    <div class="footer-left">
      <a href="{{ url('/') }}/">{{ env('APP_NAME') }}</a>
    </div>
    <div class="footer-right">
      1.0
    </div>
  </footer>