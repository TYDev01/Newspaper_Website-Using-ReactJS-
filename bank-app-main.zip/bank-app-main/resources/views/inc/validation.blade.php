@error($input)
    <span class="text-danger" role="alert">
        <small>{{ $message }}</small>
    </span>
@enderror

@if (Session::has($input))
    <span class="text-danger" role="alert">
        <small>{{ Session::get($input) }}</small>
    </span>
@endif