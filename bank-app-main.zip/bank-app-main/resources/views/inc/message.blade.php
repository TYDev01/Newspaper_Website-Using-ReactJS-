@if(Session::has('message'))
    <p class="alert alert-{{Session::get('type', 'danger')}}">
        {{ Session::get('message') }}
    </p>
@endif