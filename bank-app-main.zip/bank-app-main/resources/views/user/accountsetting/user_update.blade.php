@extends('layouts.frontend.app')

<style>
    @media(min-width: 768px) {
        hr {
            display: none;
        }
    }
</style>

@section('content')
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                @include('layouts.frontend.partials.sidebar')
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h4>{{ __('Account Settings') }}</h4>
                                </div>
                                {{-- <div class="col-lg-6">
                                    <div class="button-btn">
                                        <a class="f-right" href="{{ route('user.account.password.change') }}">{{ __('Password Change') }}</a>
                                    </div>
                                </div> --}}
                            </div>
                            @include('inc.message')
                        </div>
                        @if ($errors->any())
                        <div class="alert alert-danger">
                            <strong>{{ __('woops!') }}</strong> {{ __('There were some problems with your input.') }}<br><br>
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                        @endif
                        @if (Session::has('success'))
                           <div class="alert alert-success">{{ Session::get('success') }}</div>
                        @endif
                        @if (Session::has('error'))
                        <div class="alert alert-danger">{{ Session::get('error') }}</div>
                        @endif
                        <div class="section-body">
                            <div class="card">
                                <div class="card-header">
                                    <h5>{{ __('Account Profile') }}</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>{{ __('Name') }}</label>
                                                <input type="text" placeholder="{{ __('Enter Your Name') }}" class="form-control" value="{{ Auth::user()->name }}" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>{{ __('Email') }}</label>
                                                <input type="email" placeholder="{{ __('Enter Your Email') }}" class="form-control" value="{{ Auth::user()->email }}" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>{{ __('Phone Number') }}</label>
                                                <input type="text" placeholder="{{ __('Phone Number') }}" class="form-control" value="{{ Auth::user()->phone }}" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>{{ __('Country') }}</label>
                                                <input type="text" placeholder="{{ __('Country') }}" class="form-control" value="{{ Auth::user()->country }}" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>{{ __('City') }}</label>
                                                <input type="text" placeholder="{{ __('City') }}" class="form-control" value="{{ Auth::user()->city }}" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label>{{ __('Zip Code') }}</label>
                                                <input type="text" placeholder="{{ __('Zip Code') }}" class="form-control" value="{{ Auth::user()->zip_code }}" disabled>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label>{{ __('Address') }}</label>
                                                <input type="text" placeholder="{{ __('Address') }}" class="form-control" value="{{ Auth::user()->address }}" disabled>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                        </div>
                        <hr>
                        <div class="section-body">
                            <div class="card">
                                <div class="card-header">
                                    <h5>{{ __('Account Info Update') }}</h5>
                                </div>
                                <div class="card-body row">
                                    <form method="POST" action="{{ route('user.account.update', ['tab' => 'ssn']) }}" class="basicform col-md-6">
                                        @csrf
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label>{{ __('Social Security Number') }}</label>
                                                    <input type="text" placeholder="{{ __('Enter Your Social Security Number') }}" class="form-control" name="ssn" value="{{ Auth::user()->ssn }}" minlength="9" maxlength="9" required>
                                                </div>
                                            </div>

                                            <div class="col-lg-12">
                                                <div class="button-btn">
                                                    <button type="submit" class="basicbtn w-100">{{ __('Update') }}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <hr class="my-4">
                                    <form method="POST" action="{{ route('user.account.update', ['tab' => 'pin']) }}" class="col-md-6">
                                        @csrf
                                        <div class="row">
                                            @if ( Auth::user()->pin)
                                                <div class="col-12">
                                                    <div class="form-group">
                                                        <label>{{ __('Current Transaction Pin') }}</label>
                                                        <input type="password" placeholder="{{ __('Enter your 4 digit transaction pin') }}" class="form-control" name="current_pin" minlength="4" maxlength="4" autocomplete="new-password" required>
                                                    </div>
                                                </div>
                                            @endif
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label>{{ __('New Transaction Pin') }}</label>
                                                    <input type="password" placeholder="{{ __('Enter a 4 digit transaction pin') }}" class="form-control" name="pin" minlength="4" maxlength="4" autocomplete="new-password" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label>{{ __('Confirm Transaction Pin') }}</label>
                                                    <input type="password" placeholder="{{ __('Confirm your 4 digit transaction pin') }}" class="form-control" name="pin_confirmation" minlength="4" maxlength="4" autocomplete="new-password" required>
                                                </div>
                                            </div>

                                            <div class="col-lg-12">
                                                <div class="button-btn">
                                                    <button type="submit" class="w-100">{{ __('Update Transaction Pin') }}</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
@endsection