@extends('layouts.frontend.app')


@section('content')
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                @include('layouts.frontend.partials.sidebar')
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4>{{ __('Local Transfer') }}</h4>
                        </div>
                        @include('inc.message')
                        <div class="card">
                            <div class="card-body">
                               <form action="{{ route('user.transfer.ownbank.confirm') }}" method="post">
                                @csrf
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Account') }}</label>
                                                <input type="text" name="account_no" value="{{ old('account_no') }}" class="{{ Session::has('account_no') || $errors->has('account_no') ? 'is-invalid' : '' }} form-control" placeholder="{{ __('Account Number') }}" required>

                                                @include('inc.validation', ['input' => 'account_no'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Amount') }}</label>
                                                <input type="number" name="amount" class="{{ Session::has('amount') || $errors->has('amount') ? 'is-invalid' : '' }} form-control" value="{{ old('amount') }}" placeholder="{{ __('Amount') }}" required>

                                                @include('inc.validation', ['input' => 'amount'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Bank Name') }}</label>
                                                <input type="text" name="bank_name" class="{{ Session::has('bank_name') || $errors->has('bank_name') ? 'is-invalid' : '' }} form-control" value="{{ old('bank_name') }}" placeholder="{{ __('Bank Name') }}" required>

                                                @include('inc.validation', ['input' => 'bank_name'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Description (optional)') }}</label>
                                                <textarea type="text" name="description" class="{{ Session::has('description') || $errors->has('description') ? 'is-invalid' : '' }} form-control" placeholder="{{ __('Enter a brief description for this transaction (optional)') }}" minlength="5" maxlength="200">{{old('description')}}</textarea>

                                                @include('inc.validation', ['input' => 'description'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Transaction Pin') }}</label>
                                                <input type="password" name="pin" class="{{ Session::has('pin') || $errors->has('pin') ? 'is-invalid' : '' }} form-control" placeholder="{{ __('Enter your Transaction Pin') }}" minlength="4" maxlength="4" autocomplete="new-password" required>

                                                @include('inc.validation', ['input' => 'pin'])
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-lg-12 text-center mt-3">
                                            <div class="button-btn">
                                                <button type="submit" class="d-block w-100">{{ __('Submit') }}</button>
                                            </div>
                                        </div>
                                    </div>
                               </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
@endsection

