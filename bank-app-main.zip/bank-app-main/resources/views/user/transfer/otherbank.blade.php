@extends('layouts.frontend.app')

@push('css')
  <link rel="stylesheet" href="{{ asset('backend/admin/assets/css/select2.min.css') }}">
@endpush
@section('content')
<!-- dahboard area start -->
<section>
    <div class="dashboard-area pt-150 pb-100">
        <div class="container">
            <div class="row">
                @include('layouts.frontend.partials.sidebar')
                <div class="col-lg-9">
                    <div class="main-container">
                        <div class="header-section">
                            <h4>{{ __('Other Bank Transfer') }}</h4>
                        </div>
                        @include('inc.message')
                        <div class="card">
                            <div class="card-body">
                               <form action="{{ route('user.transfer.otherbank.confirm') }}" method="post">
                                @csrf
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Country') }}</label>
                                                <select name="country" id="country" class="form-control" required>
                                                    <option value="">-- {{ __('Select Country') }} --</option>
                                                    @foreach ($countries as $country)
                                                        <option value="{{ $country->name }}" @if ($country->name == old('country')) selected @endif>{{ $country->name }}</option>
                                                    @endforeach
                                                </select>

                                                @include('inc.validation', ['input' => 'country'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Bank Name') }}</label>
                                                <input type="text" name="bank_name" id="banks" class="form-control" placeholder="{{ __('Enter Bank Name') }}" value="{{ old('bank_name') }}" required>
                                                
                                                @include('inc.validation', ['input' => 'bank_name'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Currency') }}</label>
                                                <select name="currency" class="form-control" required>
                                                    <option value="">-- {{ __('Select Currency') }} --</option>
                                                    @foreach ($currencies as $currency)
                                                    <option value="{{ $currency->id }}" @if ($currency->id == old('currency')) selected @endif>{{ $currency->title }}</option>
                                                    @endforeach
                                                </select>

                                                @include('inc.validation', ['input' => 'currency'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Branch (Address)') }}</label>
                                                <input name="branch" class="form-control" type="text" placeholder="{{ __('Enter Branch Name') }}" value="{{ old('branch') }}" required>

                                                @include('inc.validation', ['input' => 'branch'])
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Account Holder Name') }}</label>
                                                <input type="text" name="account_holder_name" class="form-control" placeholder="{{ __('Account Holder Name') }}" value="{{ old('account_holder_name') }}" required>

                                                @include('inc.validation', ['input' => 'account_holder_name'])
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Account Number') }}</label>
                                                <input type="text" class="form-control" name="account_no" placeholder="{{ __('Enter Account Number') }}" value="{{ old('account_no') }}" required>

                                                @include('inc.validation', ['input' => 'account_no'])
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Amount (USD)') }}</label>
                                                <input type="number" name="amount" class="{{ Session::has('amount') ? 'is-invalid' : '' }} form-control" value="{{ old('amount') }}" placeholder="{{ __('Amount') }}" required>

                                                @include('inc.validation', ['input' => 'amount'])
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Routing Number') }}</label>
                                                <input type="number" class="form-control" name="routing_no" placeholder="{{ __('Enter Routing Number') }}" required value="{{ old('routing_no') }}">

                                                @include('inc.validation', ['input' => 'routing_no'])
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Swift Code') }}</label>
                                                <input type="text" class="form-control" name="swift_code" placeholder="{{ __('Enter Swift Code') }}" required value="{{ old('swift_code') }}">

                                                @include('inc.validation', ['input' => 'swift_code'])
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Description (optional)') }}</label>
                                                <textarea type="text" name="description" class="{{ Session::has('description') || $errors->has('description') ? 'is-invalid' : '' }} form-control" placeholder="{{ __('Enter a brief description for this transaction (optional)') }}" minlength="5" maxlength="200">{{old('description')}}</textarea>

                                                @include('inc.validation', ['input' => 'description'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="">{{ __('Transaction Pin') }}</label>
                                                <input type="password" name="pin" class="{{ Session::has('pin') || $errors->has('pin') ? 'is-invalid' : '' }} form-control" placeholder="{{ __('Enter your Transaction Pin') }}" minlength="4" maxlength="4" autocomplete="new-password" required>

                                                @include('inc.validation', ['input' => 'pin'])
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12 text-center mt-3">
                                            <div class="button-btn">
                                                <button type="submit" class="d-block w-100">{{ __('Submit') }}</button>
                                            </div>
                                        </div>
                                    </div>
                               </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- dahboard area end -->
<input type="hidden" id="otherbank_country" value="{{ route("user.transfer.otherbank.country") }}">
@endsection

@push('js')
<script src="{{ asset('backend/admin/assets/js/select2.min.js') }}"></script>    
<script src="{{ asset('frontend/assets/js/transfer/otherbank.js') }}"></script>
@endpush