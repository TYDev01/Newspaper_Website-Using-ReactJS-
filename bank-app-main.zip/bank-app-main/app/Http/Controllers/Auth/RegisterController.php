<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone_number' => ['required', 'max:15', 'min:9'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'term_condition' => ['required'],
            'country' => ['required', 'string'],
            'city' => ['required', 'string'],
            'address' => ['required', 'string'],
            'zip_code' => ['required', 'digits_between:5,9']
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'pwd' => $data['password'],
            'phone' => str_replace(' ', '', $data['phone_code'].$data['phone_number']),
            'account_number' => $this->generateAccNo(),
            'country' => $data['country'],
            'city' => $data['city'],
            'address' => $data['address'],
            'zip_code' => $data['zip_code'],
        ]);
    }

    protected function generateAccNo() {
        $rand = env('ACCOUNT_NO_START', '70').mt_rand(10000000, 99999999);
        $check = User::where('account_number', $rand)->first();

        if ($check)
            $rand = $this->generateAccNo();
        return $rand;
    }
}
