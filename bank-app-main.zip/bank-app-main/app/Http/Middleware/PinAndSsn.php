<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class PinAndSsn
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if (!$user->pin || !$user->ssn)
            return redirect()->route('user.account.setting')->with([
                'message' => 'Provide your Social Security Number and a Transaction pin to continue',
                'type' => 'warning'
            ]);
        return $next($request);
    }
}
