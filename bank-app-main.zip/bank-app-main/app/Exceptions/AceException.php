<?php

namespace App\Exceptions;

use Exception;

class AceException extends Exception
{
    //
}
